"""
NASTRAN BDF File Generator for SOL145 Flutter Analysis
=====================================================

Generates validated NASTRAN Bulk Data Files for panel flutter analysis using
doublet lattice method (CAERO1) for reliable aerodynamic modeling.
"""

from pathlib import Path
from typing import Dict, Any, List, Optional
from dataclasses import dataclass
import datetime
import logging

logger = logging.getLogger(__name__)


@dataclass
class PanelConfig:
    """Panel configuration for BDF generation"""
    length: float  # mm
    width: float   # mm
    thickness: float  # mm
    nx: int  # elements in x direction
    ny: int  # elements in y direction
    material_id: int = 1
    property_id: int = 1


@dataclass
class MaterialConfig:
    """Material properties for BDF (NASTRAN mm-kg-s-N system)"""
    youngs_modulus: float  # MPa (N/mm^2)
    poissons_ratio: float  # dimensionless
    density: float  # kg/mm^3 = original_kg_per_m3 * 1e-9
    shear_modulus: Optional[float] = None  # MPa (N/mm^2)
    material_id: int = 1


@dataclass
class AeroConfig:
    """Aerodynamic configuration for BDF (NASTRAN mm-kg-s-N system)"""
    mach_number: float
    reference_velocity: float  # mm/s
    reference_chord: float  # mm
    reference_density: float  # kg/mm^3 = kg/m^3 * 1e-9
    altitude: float = 10000  # meters (for proper density calculation)
    reduced_frequencies: List[float] = None
    velocities: List[float] = None  # mm/s


class Sol145BDFGenerator:
    """NASTRAN BDF file generator for SOL145 flutter analysis with correct piston theory"""

    def __init__(self, output_dir: str = "."):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def generate_bdf(
        self,
        panel: PanelConfig,
        material: MaterialConfig,
        aero: AeroConfig,
        boundary_conditions: str = "SSSS",
        n_modes: int = 10,
        output_filename: str = "flutter_analysis.bdf",
        aerodynamic_theory: Optional[str] = None,
        material_object: Optional[Any] = None
    ) -> str:
        """Generate a NASTRAN BDF file for SOL145 flutter analysis with correct cards"""

        filepath = self.output_dir / output_filename
        lines = []

        # Check if we have a composite laminate
        is_composite = (material_object is not None and
                       type(material_object).__name__ == 'CompositeLaminate')

        # Header comments
        lines.append("$ NASTRAN SOL145 FLUTTER ANALYSIS - CORRECTED PISTON THEORY")
        lines.append(f"$ Generated: {datetime.datetime.now()}")
        lines.append(f"$ Panel: {panel.length}mm x {panel.width}mm")
        lines.append(f"$ Mach number: {aero.mach_number}")
        lines.append("$")

        # Executive control
        lines.append("SOL 145")
        lines.append("CEND")

        # Case control
        lines.append("TITLE = Panel Flutter Analysis - Piston Theory")
        lines.append("ECHO = NONE")
        lines.append("SPC = 1")
        lines.append("METHOD = 1")
        lines.append("FMETHOD = 1")
        lines.append("BEGIN BULK")
        lines.append("$")

        # Parameters
        lines.append("PARAM   COUPMASS1")
        lines.append("PARAM   GRDPNT  0")
        # PARAM VREF for velocity conversion (if velocities in in/s, converts to ft/s for output)
        lines.append("PARAM   VREF    1.0")  # Will be adjusted based on unit system

        # Structural Damping - CRITICAL FIX for NASTRAN 2019 bug
        # TABDMP1 is not applied correctly in SOL 145 PK method in some NASTRAN versions
        # Use PARAM W3 as workaround: W3 = critical damping ratio (0.03 = 3% damping)
        lines.append("PARAM   W3      0.03")
        lines.append("$ W3=0.03: Uniform 3% critical damping on all modes (aerospace standard)")
        # Keep TABDMP1 for compatibility with newer NASTRAN versions
        lines.append("PARAM   KDAMP   1")
        lines.append("$ KDAMP=1: Use TABDMP1 with ID=1 (backup for NASTRAN versions that support it)")

        # PARAM OPPHIPA for higher-order piston theory (includes angle-of-attack effects)
        # Only add if using piston theory (checked later in code)
        if aerodynamic_theory == "PISTON_THEORY" or (aerodynamic_theory is None and aero.mach_number >= 1.5):
            lines.append("PARAM   OPPHIPA 1")
            lines.append("$ OPPHIPA=1: Use higher-order piston theory for better accuracy at M<3")
        lines.append("$")

        # Material and Property Cards - Handle isotropic vs composite
        if is_composite:
            lines.append("$ Composite Laminate Material Properties")
            lines.append(f"$ Laminate: {material_object.name}")
            lines.append(f"$ Total thickness: {material_object.total_thickness} mm")
            lines.append(f"$ Number of plies: {len(material_object.laminas)}")
            lines.append("$")

            # Write MAT8 cards for each unique material
            # Track unique materials to avoid duplicates
            unique_materials = {}
            mat_id = 1

            for lamina in material_object.laminas:
                mat_name = lamina.material.name
                if mat_name not in unique_materials:
                    unique_materials[mat_name] = (mat_id, lamina.material)
                    mat_id += 1

            # Write MAT8 cards
            lines.append("$ Orthotropic Material Cards (MAT8)")
            for mat_name, (mid, mat) in unique_materials.items():
                lines.append(f"$ Material: {mat_name}")
                # MAT8 format: MID E1 E2 NU12 G12 G1Z G2Z RHO
                # Convert from Pa to MPa (N/mm²)
                e1_mpa = mat.e1 / 1e6
                e2_mpa = mat.e2 / 1e6
                g12_mpa = mat.g12 / 1e6
                g1z_mpa = (mat.g1z / 1e6) if mat.g1z else g12_mpa
                g2z_mpa = (mat.g2z / 1e6) if mat.g2z else (g12_mpa * 0.5)
                rho_kg_mm3 = mat.density * 1e-9  # kg/m³ to kg/mm³

                lines.append(f"MAT8    {mid:<8}{e1_mpa:<8.1f}{e2_mpa:<8.1f}{mat.nu12:<8.3f}{g12_mpa:<8.1f}{g1z_mpa:<8.1f}{g2z_mpa:<8.1f}{rho_kg_mm3:<8.2E}")
            lines.append("$")

            # Write PCOMP card - NASTRAN 2017 compatible format
            lines.append("$ Composite Property Card (PCOMP)")
            lines.append(f"$ Laminate: {material_object.name}")
            # PCOMP format for NASTRAN 2017: PCOMP PID Z0 NSM SB FT TREF GE LAM +
            # NASTRAN 2017 requires: simple continuation (+1, +2), proper field counts
            pid = 1
            # 8-character fixed field format (9 fields + continuation = 80 chars)
            lines.append(f"PCOMP   {pid:<8}                                                        +1")

            # Write continuation cards with ply data - NASTRAN 2017 format
            # Continuation format: +1, +2, +3... (simple numbering)
            # Each line: continuation_marker(8) + 2 plies max (8 fields) + next_continuation(8)
            # Format per ply: MID(8) T(8) THETA(8) SOUT(8)

            cont_num = 1
            ply_count = 0
            ply_line = f"+{cont_num:<7}"  # +1, +2, etc (8 chars total with padding)

            for i, lamina in enumerate(material_object.laminas):
                mat_name = lamina.material.name
                mid = unique_materials[mat_name][0]
                thickness_mm = lamina.thickness  # Already in mm
                theta = lamina.orientation

                # Add ply data: MID T THETA SOUT (each field 8 chars)
                ply_line += f"{mid:<8}{thickness_mm:<8.4f}{theta:<8.1f}{'':8}"
                ply_count += 1

                # Two plies per line max (2 plies = 8 fields)
                if ply_count == 2 and (i + 1) < len(material_object.laminas):
                    # Add continuation marker and write line
                    cont_num += 1
                    ply_line += f"+{cont_num:<7}"
                    lines.append(ply_line)
                    ply_line = f"+{cont_num:<7}"
                    ply_count = 0

            # Write final line if there's remaining data
            if ply_count > 0:
                lines.append(ply_line)
            lines.append("$")

        else:
            # Isotropic material - MAT1 and PSHELL
            # Calculate shear modulus if not provided
            if material.shear_modulus is None:
                G = material.youngs_modulus / (2 * (1 + material.poissons_ratio))
            else:
                G = material.shear_modulus

            lines.append("$ Material Properties (NASTRAN mm-kg-s-N system)")
            # MAT1: MID E G NU RHO A TREF GE
            # CRITICAL: Must use proper 8-character fixed field format
            # Units: E (MPa=N/mm²), G (MPa), NU (dimensionless), RHO (kg/mm³)
            # Match format from working examples: "73100.  " style (note: single decimal point)

            # Format E and G - use format with single decimal point and spaces
            # .1f already includes decimal point, so don't add another
            E_str = f"{material.youngs_modulus:.1f}"
            E_field = f"{E_str:<8.8}"  # Left-align, pad to 8 chars

            G_str = f"{G:.1f}"
            G_field = f"{G_str:<8.8}"

            # Poisson's ratio as .XX format
            nu_str = f".{int(material.poissons_ratio*100):02d}"
            nu_field = f"{nu_str:<8.8}"

            # Density in scientific notation (space before to match working format)
            rho_str = f"{material.density:.2E}"
            # Ensure proper spacing - add space before if needed
            rho_field = f" {rho_str}" if len(rho_str) == 7 else rho_str
            rho_field = f"{rho_field:<8.8}"

            # Thermal expansion coefficient
            A_str = f"{2.1E-05:.1E}"
            A_field = f" {A_str}" if len(A_str) == 7 else A_str
            A_field = f"{A_field:<8.8}"

            mat1_line = f"MAT1    1       {E_field}{G_field}{nu_field}{rho_field}{A_field}"
            lines.append(mat1_line)
            lines.append("$")

            # Shell property
            lines.append("$ Shell Property")
            # PSHELL format: PID MID1 T MID2 12I/T^3 MID3 TS/T NSM Z1 Z2
            # Field positions: 1-8, 9-16, 17-24, 25-32, 33-40, ...
            # CRITICAL FIX: MID2 must be in field 4 (columns 25-32), not field 5
            # Previous bug had extra spaces causing MID2=1 to land in 12I/T^3 field
            # Correct format: PID, MID1, T, MID2 all in separate 8-char fields (NASTRAN fixed format)
            # Field 1: Card name, Field 2: PID, Field 3: MID1, Field 4: T, Field 5: MID2
            t_str = f"{panel.thickness:.4f}"
            lines.append(f"PSHELL  1       1       {t_str:<8}{'1':<8}")
            lines.append("$")

        # Grid points
        lines.append("$ Grid Points")
        grid_id = 1
        dx = panel.length / panel.nx
        dy = panel.width / panel.ny

        for j in range(panel.ny + 1):
            for i in range(panel.nx + 1):
                x = i * dx
                y = j * dy
                z = 0.0
                lines.append(f"GRID    {grid_id:<8}        {x:<8.1f}{y:<8.1f}{z:<8.1f}")
                grid_id += 1
        lines.append("$")

        # Elements
        lines.append("$ Elements")
        elem_id = 1
        for j in range(panel.ny):
            for i in range(panel.nx):
                n1 = j * (panel.nx + 1) + i + 1
                n2 = n1 + 1
                n3 = n1 + panel.nx + 2
                n4 = n1 + panel.nx + 1
                lines.append(f"CQUAD4  {elem_id:<8}{panel.property_id:<8}{n1:<8}{n2:<8}{n3:<8}{n4:<8}")
                elem_id += 1
        lines.append("$")

        # Boundary conditions
        lines.append("$ Boundary Conditions")
        # Handle both string and Enum types
        if hasattr(boundary_conditions, 'value'):
            bc_str = boundary_conditions.value
        else:
            bc_str = str(boundary_conditions)

        # Calculate total nodes
        total_nodes = (panel.nx + 1) * (panel.ny + 1)

        if bc_str.upper() == "SSSS":
            # Simply supported - constrain Z displacement on all edges
            lines.append("$ SSSS: Simply Supported on all four edges")
            edge_nodes = []

            # Bottom edge (j=0)
            for i in range(panel.nx + 1):
                edge_nodes.append(i + 1)

            # Top edge (j=ny)
            for i in range(panel.nx + 1):
                edge_nodes.append((panel.ny) * (panel.nx + 1) + i + 1)

            # Left edge (i=0) - skip corners
            for j in range(1, panel.ny):
                edge_nodes.append(j * (panel.nx + 1) + 1)

            # Right edge (i=nx) - skip corners
            for j in range(1, panel.ny):
                edge_nodes.append(j * (panel.nx + 1) + panel.nx + 1)

            # Remove duplicates and sort
            edge_nodes = sorted(set(edge_nodes))

            # Write a single SPC1 card with continuation
            spc_line = "SPC1    1       3       "
            for i, node in enumerate(edge_nodes):
                if i > 0 and i % 6 == 0:
                    lines.append(spc_line)
                    spc_line = "+       "  # Continuation
                spc_line += f"{node:<8}"
            if spc_line.strip():
                lines.append(spc_line)

        elif bc_str.upper() == "CCCC":
            # Clamped - constrain all translations and rotations on all edges
            lines.append("$ CCCC: Clamped on all four edges")
            edge_nodes = []

            # Bottom edge (j=0)
            for i in range(panel.nx + 1):
                edge_nodes.append(i + 1)

            # Top edge (j=ny)
            for i in range(panel.nx + 1):
                edge_nodes.append((panel.ny) * (panel.nx + 1) + i + 1)

            # Left edge (i=0) - skip corners to avoid duplicates
            for j in range(1, panel.ny):
                edge_nodes.append(j * (panel.nx + 1) + 1)

            # Right edge (i=nx) - skip corners to avoid duplicates
            for j in range(1, panel.ny):
                edge_nodes.append(j * (panel.nx + 1) + panel.nx + 1)

            # Remove duplicates and sort
            edge_nodes = sorted(set(edge_nodes))

            # Write SPC1 card constraining all DOFs (123456) on edge nodes
            spc_line = "SPC1    1       123456  "
            for i, node in enumerate(edge_nodes):
                if i > 0 and i % 6 == 0:
                    lines.append(spc_line)
                    spc_line = "+       "  # Continuation
                spc_line += f"{node:<8}"
            if spc_line.strip():
                lines.append(spc_line)

        elif bc_str.upper() == "CFFF":
            # Cantilever - clamped at x=0, free elsewhere
            lines.append("$ CFFF: Clamped at x=0 (left edge), Free-Free-Free on other edges")
            left_edge_nodes = []

            # Left edge only (i=0, all j)
            for j in range(panel.ny + 1):
                left_edge_nodes.append(j * (panel.nx + 1) + 1)

            # Write SPC1 card constraining all DOFs on left edge
            spc_line = "SPC1    1       123456  "
            for i, node in enumerate(left_edge_nodes):
                if i > 0 and i % 6 == 0:
                    lines.append(spc_line)
                    spc_line = "+       "  # Continuation
                spc_line += f"{node:<8}"
            if spc_line.strip():
                lines.append(spc_line)

        elif bc_str.upper() == "CFCF":
            # Clamped-Free-Clamped-Free: clamped at x=0 and x=length, free at y=0 and y=width
            lines.append("$ CFCF: Clamped at x=0 and x=L, Free at y=0 and y=W")
            edge_nodes = []

            # Left edge (i=0, all j)
            for j in range(panel.ny + 1):
                edge_nodes.append(j * (panel.nx + 1) + 1)

            # Right edge (i=nx, all j)
            for j in range(panel.ny + 1):
                edge_nodes.append(j * (panel.nx + 1) + panel.nx + 1)

            # Remove duplicates and sort
            edge_nodes = sorted(set(edge_nodes))

            # Write SPC1 card constraining all DOFs on clamped edges
            spc_line = "SPC1    1       123456  "
            for i, node in enumerate(edge_nodes):
                if i > 0 and i % 6 == 0:
                    lines.append(spc_line)
                    spc_line = "+       "  # Continuation
                spc_line += f"{node:<8}"
            if spc_line.strip():
                lines.append(spc_line)

        elif bc_str.upper() == "SCSC":
            # Simply supported-Clamped-Simply supported-Clamped
            lines.append("$ SCSC: Simply Supported at x=0 and x=L, Clamped at y=0 and y=W")

            # Left and right edges: Simply supported (DOF 3 only)
            ss_edge_nodes = []
            for j in range(panel.ny + 1):
                ss_edge_nodes.append(j * (panel.nx + 1) + 1)  # Left edge
                ss_edge_nodes.append(j * (panel.nx + 1) + panel.nx + 1)  # Right edge
            ss_edge_nodes = sorted(set(ss_edge_nodes))

            spc_line = "SPC1    1       3       "
            for i, node in enumerate(ss_edge_nodes):
                if i > 0 and i % 6 == 0:
                    lines.append(spc_line)
                    spc_line = "+       "  # Continuation
                spc_line += f"{node:<8}"
            if spc_line.strip():
                lines.append(spc_line)

            # Bottom and top edges: Clamped (DOF 123456) - excluding corners already constrained
            c_edge_nodes = []
            for i in range(1, panel.nx):  # Skip corners to avoid double constraint
                c_edge_nodes.append(i + 1)  # Bottom edge
                c_edge_nodes.append((panel.ny) * (panel.nx + 1) + i + 1)  # Top edge

            spc_line = "SPC1    1       123456  "
            for i, node in enumerate(c_edge_nodes):
                if i > 0 and i % 6 == 0:
                    lines.append(spc_line)
                    spc_line = "+       "  # Continuation
                spc_line += f"{node:<8}"
            if spc_line.strip():
                lines.append(spc_line)

        else:
            # Unknown boundary condition - default to SSSS with warning
            lines.append(f"$ WARNING: Unknown boundary condition '{bc_str}' - defaulting to SSSS")
            lines.append("$ SSSS: Simply Supported on all four edges")
            edge_nodes = []

            for i in range(panel.nx + 1):
                edge_nodes.append(i + 1)
                edge_nodes.append((panel.ny) * (panel.nx + 1) + i + 1)

            for j in range(1, panel.ny):
                edge_nodes.append(j * (panel.nx + 1) + 1)
                edge_nodes.append(j * (panel.nx + 1) + panel.nx + 1)

            edge_nodes = sorted(set(edge_nodes))

            spc_line = "SPC1    1       3       "
            for i, node in enumerate(edge_nodes):
                if i > 0 and i % 6 == 0:
                    lines.append(spc_line)
                    spc_line = "+       "
                spc_line += f"{node:<8}"
            if spc_line.strip():
                lines.append(spc_line)

        # Add constraints to prevent in-plane rigid body modes (per MSC Nastran reference)
        # Constrain X translation at corner node 1 to prevent X rigid body translation
        lines.append("SPC1    1       1       1")

        # Constrain Y translation at TWO corners (nodes 1 and last node) to prevent
        # Y rigid body translation AND in-plane rotation about Z-axis
        lines.append(f"SPC1    1       2       1       {total_nodes}")

        # Constrain drilling DOF (DOF 6) on ALL nodes
        # CRITICAL: CQUAD4 elements have zero stiffness for drilling rotation (rotation about Z)
        # Must constrain DOF 6 to prevent grid point singularities (per MSC Nastran reference)
        lines.append(f"SPC1    1       6       1       THRU    {total_nodes}")
        lines.append("$")

        # Eigenvalue extraction
        lines.append("$ Eigenvalue Extraction")
        sid = 1
        msglvl = 0  # Set to 0 to avoid MSGLVL:10 <= 4 error
        # Using EIGRL (Lanczos) for now - more reliable with fixed-field format
        lines.append(f"EIGRL   {sid:8d}{'':16}{n_modes:8d}{msglvl:8d}")
        lines.append("$")

        # Aerodynamic reference - VALIDATED FORMAT
        lines.append("$ Aerodynamic Reference")
        lines.append("$ AERO: ACSID VELOCITY REFC RHOREF")
        lines.append("$   ACSID=0: Basic coordinate system")
        lines.append("$   VELOCITY=1.0: Reference velocity (actual velocities in FLFACT)")
        lines.append(f"$   REFC={panel.length:.1f}: Reference chord length (mm)")
        lines.append(f"$   RHOREF: Reference density (kg/mm³ = kg/m³ × 1e-9)")
        # AERO card with correct air density in kg/mm³
        # Format: AERO ACSID VELOCITY REFC RHOREF
        # Use compact NASTRAN scientific notation (e.g., 1.225-9 instead of 1.225E-09)
        import math
        if aero.reference_density != 0:
            exponent = int(math.floor(math.log10(abs(aero.reference_density))))
            mantissa = aero.reference_density / (10 ** exponent)
            # Format as: mantissa+exponent or mantissa-exponent (8 chars max)
            rho_str = f"{mantissa:.3f}{exponent:+d}"  # e.g., "1.225-9"
            # Log the actual density for verification
            rho_kg_m3 = aero.reference_density * 1e9  # Convert back to kg/m³ for readability
            lines.append(f"$ Reference density: {rho_kg_m3:.4f} kg/m³ (altitude: {aero.altitude}m)")
        else:
            rho_str = "0.0"
        lines.append(f"AERO    0       1.      {panel.length:<8.1f}{rho_str:<8s}")
        lines.append("$")

        # AERODYNAMIC MODEL - Select based on Mach number
        # Determine aerodynamic theory based on user selection or Mach number
        # User selection takes priority, otherwise use Mach-based logic
        if aerodynamic_theory:
            # Explicit user choice
            use_piston_theory = (aerodynamic_theory == "PISTON_THEORY")
        else:
            # Auto-select based on Mach number: CAERO5 for M >= 1.5, CAERO1 for M < 1.5
            use_piston_theory = (aero.mach_number >= 1.5)

        if use_piston_theory:
            # CAERO5 - Piston Theory for supersonic flow (M >= 1.5)
            lines.append("$ Piston Theory (CAERO5) - Supersonic Aerodynamics")
            lines.append("$ Reference: MSC Nastran Aeroelastic Analysis User's Guide, Example HA145HA")
            lines.append("$")

            # AEFACT 10 - Thickness integrals for piston theory (flat panel = all zeros)
            lines.append("$ Thickness Integrals (I1-I6) - flat panel")
            lines.append(f"AEFACT  {10:<8}{0.0:<8}{0.0:<8}{0.0:<8}{0.0:<8}{0.0:<8}{0.0:<8}")
            lines.append("$")

            # AEFACT 20 for Mach/alpha combinations - Reference has M=2.0 and M=3.0
            lines.append("$ Mach and Alpha Combinations")
            lines.append(f"AEFACT  {20:<8}{aero.mach_number:<8.1f}{0.0:<8}{3.0:<8}{0.0:<8}")
            lines.append("$")

            # PAERO5 - Piston Theory Property (REQUIRED with two continuation lines)
            # Format from MSC Nastran Example HA145HA (Listing 8-30)
            lines.append("$ Piston Theory Property")
            pid_aero = 1001
            nalpha = 1  # Number of alpha values
            lalpha = 20  # AEFACT ID for alpha values
            # Main card: PAERO5, PID, NALPHA, LALPHA, blank fields, then continuation in field 10 (position 72)
            # Fields: 1=PAERO5, 2=PID, 3=NALPHA, 4=LALPHA, 5-9=blank (40 chars), 10=continuation
            lines.append(f"PAERO5  {pid_aero:<8}{nalpha:<8}{lalpha:<8}{'':40}+PA5")
            # First continuation: 8 CAOC values (control surface parameters, zeros for flat panel)
            lines.append(f"+PA5    {0.0:<8.1f}{0.0:<8.1f}{0.0:<8.1f}{0.0:<8.1f}{0.0:<8.1f}{0.0:<8.1f}{0.0:<8.1f}{0.0:<8.1f}+PA51")
            # Second continuation: 2 more CAOC values
            lines.append(f"+PA51   {0.0:<8.1f}{0.0:<8.1f}")
            lines.append("$")

            # CAERO5 - 10 separate panels following reference format
            # Reference: MSC Nastran Example HA145HA uses 10 CAERO5 cards (EID 1001-10001)
            lines.append("$ PISTON THEORY PANEL (CAERO5)")
            lines.append("$")

            nspan = 10  # Spanwise divisions per CAERO5 card
            lspan = 1  # AEFACT ID for spanwise spacing (optional, leave blank)
            nthick = 10  # AEFACT ID for thickness integrals

            # Panel geometry
            chord = panel.length
            strip_width = panel.width / 10  # Divide width into 10 strips

            # Generate 10 CAERO5 cards (EID 1001, 2001, 3001, ..., 10001)
            for strip in range(10):
                eid = 1001 + (strip * 1000)
                y_start = strip * strip_width
                y_end = (strip + 1) * strip_width

                # Each strip: point 1 at (0, y_start, 0), point 4 at (0, y_end, 0)
                x1, y1, z1 = 0.0, y_start, 0.0
                x12 = chord  # Chord length in x-direction
                x4, y4, z4 = 0.0, y_end, 0.0
                x43 = chord  # Chord length in x-direction

                # CAERO5 main card: EID, PID, CP, NSPAN, LSPAN, NTHRY, NTHICK, blank, continuation
                # Fields: 1=CAERO5, 2=EID, 3=PID, 4=CP, 5=NSPAN, 6=LSPAN, 7=NTHRY, 8=NTHICK, 9=blank, 10=continuation
                cont_marker = f"+CA{strip:02d}"
                lines.append(f"CAERO5  {eid:<8}{pid_aero:<8}        {nspan:<8}{'':8}        {nthick:<8}{'':8}{cont_marker}")
                # Continuation: X1, Y1, Z1, X12, X4, Y4, Z4, X43
                lines.append(f"+CA{strip:02d}   {x1:<8.1f}{y1:<8.1f}{z1:<8.1f}{x12:<8.1f}{x4:<8.1f}{y4:<8.1f}{z4:<8.1f}{x43:<8.1f}")

            lines.append("$")

            # SPLINE1 - Surface interpolation connecting aero panel to structural grids
            # Create separate SPLINE for each CAERO5 since box numbers are non-contiguous
            lines.append("$ SPLINE - SURFACE INTERPOLATION")
            setg_id = 1  # SET1 with all structural grids

            # Create one SPLINE for each CAERO5 card
            for strip in range(10):
                spline_id = strip + 1
                caero_eid = 1001 + (strip * 1000)
                box1 = caero_eid  # First box of this CAERO5
                box2 = caero_eid + (nspan - 1)  # Last box of this CAERO5

                lines.append(f"SPLINE1 {spline_id:<8}{caero_eid:<8}{box1:<8}{box2:<8}{setg_id:<8}")

            # SET1 - All structural grid points
            lines.append(f"SET1    {setg_id:<8}{1:<8}THRU    {(panel.nx + 1) * (panel.ny + 1)}")
            lines.append("$")

        else:
            # CAERO1 - Doublet Lattice Method for subsonic/transonic (M < 1.5)
            lines.append("$ Doublet Lattice Method (CAERO1) - Subsonic/Transonic")
            lines.append("$")

            lines.append("$ Doublet Lattice Method Property")
            lines.append("PAERO1  1")
            lines.append("$")

            # CAERO1 card for doublet lattice method - CORRECTED GEOMETRY
            lines.append("$ Doublet Lattice Method Panel")
            # CAERO1 format: EID PID CP NSPAN NCHORD LSPAN LCHORD IGD
            # Use minimum 8x8 mesh for adequate flutter resolution (per NASA TP-2000-209136)
            aero_nx = max(8, panel.nx // 2)  # Minimum 8 spanwise panels, or half structural mesh
            aero_ny = max(8, panel.ny // 2)  # Minimum 8 chordwise panels, or half structural mesh
            lines.append(f"CAERO1  {1:<8}{1:<8}        {aero_nx:<8}{aero_ny:<8}                1       +CA1")
            # Continuation: X1, Y1, Z1, X12, X4, Y4, Z4, X43 (all 8-char fields)
            # CRITICAL FIX: X43 should be chord length, not X-coordinate
            # Geometry: Point 1 at (0,0,0), Point 2 at (X12,0,0), Point 4 at (0,Y4,0), Point 3 at (X12,Y4,0)
            x1, y1, z1 = 0.0, 0.0, 0.0
            x12 = panel.length  # Chord length (root)
            x4, y4, z4 = 0.0, panel.width, 0.0  # Leading edge at span
            x43 = panel.length  # Chord length (tip) - CORRECTED
            lines.append(f"+CA1    {x1:<8.1f}{y1:<8.1f}{z1:<8.1f}{x12:<8.1f}{x4:<8.1f}{y4:<8.1f}{z4:<8.1f}{x43:<8.1f}")
            lines.append("$")

            # SPLINE1 for surface interpolation - MUCH MORE ROBUST
            lines.append("$ Spline - Surface Interpolation")
            # SPLINE1: EID CAERO BOX1 BOX2 SETG DZ METH USAGE NELEM MELIN
            # Critical: BOX1 and BOX2 define the aerodynamic box range
            # For CAERO1 with EID=1, boxes are numbered 1 to (NSPAN*NCHORD)
            aero_panels = aero_nx * aero_ny
            box1 = 1  # First aerodynamic box
            box2 = aero_panels  # Last aerodynamic box
            setg_id = 1  # SET1 containing all structural grids
            # DZ = 0.0 means no offset, METH blank uses default (IPS method)
            lines.append(f"SPLINE1 {1:<8}{1:<8}{box1:<8}{box2:<8}{setg_id:<8}")
            # SET1: Define all structural grid points for interpolation
            total_grids = (panel.nx + 1) * (panel.ny + 1)
            lines.append(f"SET1    {setg_id:<8}{1:<8}THRU    {total_grids:<8}")
            lines.append("$")

        # Flutter cards
        lines.append("$ Flutter Analysis")
        # CRITICAL: Add structural damping table (TABDMP1) for realistic flutter analysis
        # Without damping, NASTRAN reports zero damping at all speeds (unrealistic)
        # Typical aerospace structures: 2-5% critical damping (g = 0.02 to 0.05)
        lines.append("$ Structural Damping Table (frequency-dependent)")
        # TABDMP1 format: Line 1: TABDMP1 TID TYPE
        #                 Line 2+: f1 g1 f2 g2 ... ENDT
        # TYPE = CRIT for critical damping ratio (g), G for structural damping coefficient
        lines.append("TABDMP1 1       CRIT")
        # Frequency (Hz) and damping pairs: constant 3% critical damping (0.03) from 0-1000 Hz
        lines.append("+       0.0     0.03    1000.0  0.03    ENDT")
        lines.append("$")

        # FLUTTER card: PK method with density (1), Mach (2), reduced freq/velocity (3)
        lines.append("FLUTTER 1       PK      1       2       3       L")

        # Density ratio list (FLFACT 1) - 0.5 for one-sided flow (air on one side only)
        lines.append("FLFACT  1       0.5")

        # Mach number (FLFACT 2) - include multiple Mach numbers for comprehensive analysis
        if use_piston_theory:
            # For supersonic, test both M=2.0 and M=3.0 as in reference case
            lines.append(f"FLFACT  2       {aero.mach_number:.1f}     3.0")
        else:
            # For subsonic/transonic, use same Mach number
            lines.append(f"FLFACT  2       {aero.mach_number:.1f}     {aero.mach_number:.1f}")

        # For PK method, FLFACT 3 contains velocities
        if aero.velocities:
            # Write velocities in multiple lines if needed
            vel_idx = 0
            line_count = 0
            while vel_idx < len(aero.velocities):
                if line_count == 0:
                    vel_line = "FLFACT  3       "
                else:
                    # NASTRAN continuation line - starts with continuation marker
                    vel_line = "+FL3    "  # Exactly 8 characters for continuation marker

                # NASTRAN fixed format: 80 chars max, columns 73-80 for continuation
                # First line: FLFACT+ID (16 chars) + velocities (max 56 chars = 7 velocities) + cont (8 chars) = 80
                # Continuation: marker (8 chars) + velocities (max 64 chars = 8 velocities) = 72 chars
                max_velocities = 7 if line_count == 0 else 8  # First line has LESS space due to header
                for i in range(max_velocities):
                    if vel_idx < len(aero.velocities):
                        vel = aero.velocities[vel_idx]
                        # Format for 8-character field
                        if vel >= 1e7:
                            vel_str = f"{vel:.1e}".ljust(8)
                        elif vel >= 1e6:
                            vel_str = f"{vel/1e6:.2f}+6".ljust(8)
                        else:
                            vel_str = f"{vel:.0f}.".ljust(8)
                        vel_line += vel_str
                        vel_idx += 1
                    else:
                        break

                # Add continuation marker at end of line if more velocities follow
                if vel_idx < len(aero.velocities):
                    # Pad to position 72, then add 8-char continuation marker in columns 73-80
                    vel_line = vel_line.ljust(72) + "+FL3    "

                lines.append(vel_line)
                line_count += 1
        else:
            # Extended default velocity range: 100-2500 m/s (100,000-2,500,000 mm/s)
            # Per MIL-A-8870C: Must extend at least 15% beyond predicted flutter speed
            # Using logarithmic spacing for better resolution near flutter boundary
            lines.append("$ Extended velocity range: 100-2500 m/s for comprehensive flutter envelope")
            lines.append("FLFACT  3       1.0E+05 2.0E+05 3.0E+05 4.0E+05 5.0E+05 6.0E+05 7.0E+05 ".ljust(72) + "+FL3    ")
            lines.append("+FL3    8.0E+05 9.0E+05 1.0E+06 1.2E+06 1.4E+06 1.6E+06 1.8E+06 ".ljust(72) + "+FL31   ")
            lines.append("+FL31   2.0E+06 2.2E+06 2.5E+06")
        lines.append("$")

        # Aerodynamic matrices - select based on aerodynamic method
        if use_piston_theory:
            # MKAERO1 for piston theory (CAERO5) - Reference uses MKAERO1, not MKAERO2
            lines.append("$ Aerodynamic Matrices - Piston Theory (MKAERO1)")
            # Include both M=2.0 and M=3.0 as in reference case
            lines.append(f"MKAERO1 {aero.mach_number:<8.1f}{3.0:<8.1f}{'':48}+MK1     ")
            # Continuation card with validated reduced frequencies (MUST have leading zeros)
            lines.append("+MK1    0.001   0.1     0.2     0.4")
            lines.append("$")
        else:
            # MKAERO1 for doublet lattice (CAERO1)
            lines.append("$ Aerodynamic Matrices - Doublet Lattice (MKAERO1)")
            # Main card with Mach number only
            lines.append(f"MKAERO1 {aero.mach_number:<8.1f}{'':56}+MK1     ")
            # Continuation card with validated reduced frequencies (MUST have leading zeros)
            lines.append("+MK1    0.001   0.1     0.2     0.4")
            lines.append("$")

        # End of data
        lines.append("ENDDATA")

        # Write file
        with open(filepath, 'w') as f:
            f.write('\n'.join(lines))

        logger.info(f"Generated corrected SOL145 BDF file: {filepath}")
        return str(filepath)


def create_sol145_flutter_bdf(config: Dict[str, Any], output_dir: str = ".") -> str:
    """Create a SOL145 flutter analysis BDF file with corrected piston theory cards"""

    generator = Sol145BDFGenerator(output_dir)

    # Extract panel config
    panel = PanelConfig(
        length=config.get('panel_length', 1000.0),  # mm
        width=config.get('panel_width', 800.0),      # mm
        thickness=config.get('thickness', 2.0),       # mm
        nx=config.get('nx', 10),
        ny=config.get('ny', 10)
    )

    # Extract material config (NASTRAN units: mm-kg-s-N)
    material = MaterialConfig(
        youngs_modulus=config.get('youngs_modulus', 71700.0),  # MPa (N/mm^2)
        poissons_ratio=config.get('poissons_ratio', 0.33),
        density=config.get('density', 2.81e-9)  # kg/mm^3 (CORRECTED from 2.81e-6)
    )

    # Extract aero config
    # Calculate proper air density at altitude using ISA atmosphere model
    altitude = config.get('altitude', 10000)  # meters
    # ISA atmosphere model: ρ = ρ₀ × exp(-altitude/H) where H ≈ 8500m (scale height)
    # Reference: U.S. Standard Atmosphere 1976
    rho_sea_level_kg_m3 = 1.225  # kg/m³ at sea level, 15°C

    # More accurate ISA model for troposphere (altitude < 11000m)
    if altitude <= 11000:
        # Temperature lapse rate: -6.5°C/km
        T0 = 288.15  # Sea level temperature (K)
        T = T0 - 0.0065 * altitude  # Temperature at altitude (K)
        rho_at_alt_kg_m3 = rho_sea_level_kg_m3 * ((T / T0) ** 4.2561)
    else:
        # Stratosphere (constant temperature -56.5°C)
        # Use exponential decay approximation
        rho_at_alt_kg_m3 = rho_sea_level_kg_m3 * (2.71828 ** (-altitude / 8500.0))

    rho_at_alt_kg_mm3 = rho_at_alt_kg_m3 * 1e-9  # Convert kg/m³ to kg/mm³
    logger.info(f"ISA atmosphere at {altitude}m: rho = {rho_at_alt_kg_m3:.4f} kg/m^3")

    aero = AeroConfig(
        mach_number=config.get('mach_number', 3.0),
        reference_velocity=config.get('velocity', 1.0e6),  # mm/s
        reference_chord=config.get('panel_length', 1000.0),  # mm
        reference_density=rho_at_alt_kg_mm3,  # kg/mm³ at specified altitude (CORRECTED)
        altitude=altitude,
        reduced_frequencies=config.get('reduced_frequencies', [0.0, 0.001, 0.01, 0.1, 0.2]),
        velocities=config.get('velocities')  # mm/s
    )

    # Generate BDF
    return generator.generate_bdf(
        panel=panel,
        material=material,
        aero=aero,
        boundary_conditions=config.get('boundary_conditions', 'SSSS'),
        n_modes=config.get('n_modes', 10),
        output_filename=config.get('output_filename', 'flutter_sol145.bdf')
    )