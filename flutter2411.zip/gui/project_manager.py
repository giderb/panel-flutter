"""Project management for panel flutter analysis projects."""

import json
import os
import sys
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime
from dataclasses import dataclass, asdict

# Add python_bridge to path for validator
sys.path.insert(0, str(Path(__file__).parent.parent / "python_bridge"))

from models.material import IsotropicMaterial, OrthotropicMaterial, CompositeLaminate, material_from_dict

try:
    from python_bridge.project_validator import ProjectValidator
    VALIDATOR_AVAILABLE = True
except ImportError:
    VALIDATOR_AVAILABLE = False
    print("Warning: ProjectValidator not available")

@dataclass
class Project:
    """Panel flutter analysis project."""
    id: str
    name: str
    created_at: datetime
    modified_at: datetime
    description: Optional[str] = None

    # Analysis components
    material: Optional[Any] = None
    structural_model: Optional[Any] = None
    geometry: Optional[Dict[str, Any]] = None
    boundary_conditions: Optional[str] = None
    aerodynamic_config: Optional[Dict[str, Any]] = None
    analysis_params: Optional[Dict[str, Any]] = None
    # Results
    results: Optional[Dict[str, Any]] = None

    # Custom materials for composite layups
    custom_prepreg_materials: Optional[List[OrthotropicMaterial]] = None

    # File paths
    project_directory: Optional[str] = None
    bdf_file_path: Optional[str] = None
    f06_file_path: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert project to dictionary for serialization."""
        data = {
            "id": self.id,
            "name": self.name,
            "created_at": self.created_at.isoformat(),
            "modified_at": self.modified_at.isoformat(),
            "description": self.description,
            "geometry": self.geometry,
            "boundary_conditions": self.boundary_conditions,
            "aerodynamic_config": self.aerodynamic_config,
            "analysis_params": self.analysis_params,
            "results": self.results,
            "project_directory": self.project_directory,
            "bdf_file_path": self.bdf_file_path,
            "f06_file_path": self.f06_file_path
        }

        # Handle material serialization
        if self.material:
            if hasattr(self.material, 'to_dict'):
                data["material"] = self.material.to_dict()
            else:
                data["material"] = self.material

        # Handle structural model serialization
        if self.structural_model:
            if hasattr(self.structural_model, 'to_dict'):
                data["structural_model"] = self.structural_model.to_dict()
            else:
                data["structural_model"] = str(self.structural_model)  # Convert to string if no to_dict

        # Handle custom prepreg materials serialization
        if self.custom_prepreg_materials:
            data["custom_prepreg_materials"] = [mat.to_dict() for mat in self.custom_prepreg_materials]

        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Project':
        """Create project from dictionary."""
        # Parse datetime fields
        created_at = datetime.fromisoformat(data["created_at"])
        modified_at = datetime.fromisoformat(data["modified_at"])

        # Parse material
        material = None
        if data.get("material"):
            try:
                material = material_from_dict(data["material"])
            except Exception:
                material = data["material"]  # Keep as dict if parsing fails

        # Parse structural model (for now, keep as None - will be created by structural panel)
        structural_model = data.get("structural_model")  # Keep as raw data for now

        # Parse custom prepreg materials
        custom_prepreg_materials = None
        if data.get("custom_prepreg_materials"):
            try:
                custom_prepreg_materials = [
                    OrthotropicMaterial(**{k: v for k, v in mat_data.items() if k != "type"})
                    for mat_data in data["custom_prepreg_materials"]
                ]
            except Exception as e:
                print(f"Warning: Could not load custom prepreg materials: {e}")
                custom_prepreg_materials = None

        return cls(
            id=data["id"],
            name=data["name"],
            created_at=created_at,
            modified_at=modified_at,
            description=data.get("description"),
            material=material,
            structural_model=structural_model,
            geometry=data.get("geometry"),
            boundary_conditions=data.get("boundary_conditions"),
            aerodynamic_config=data.get("aerodynamic_config"),
            analysis_params=data.get("analysis_params"),
            results=data.get("results"),
            custom_prepreg_materials=custom_prepreg_materials,
            project_directory=data.get("project_directory"),
            bdf_file_path=data.get("bdf_file_path"),
            f06_file_path=data.get("f06_file_path")
        )

    def is_configured(self) -> bool:
        """Check if project is fully configured for analysis."""
        return all([
            self.material is not None,
            self.geometry is not None,
            self.boundary_conditions is not None,
            self.aerodynamic_config is not None,
            self.analysis_params is not None
        ])

    def get_completion_percentage(self) -> float:
        """Get project completion percentage."""
        components = [
            self.material,
            self.geometry,
            self.boundary_conditions,
            self.aerodynamic_config,
            self.analysis_params
        ]
        completed = sum(1 for comp in components if comp is not None)
        return (completed / len(components)) * 100

    def validate(self) -> List[str]:
        """Validate project configuration and return list of errors."""
        errors = []

        if not self.material:
            errors.append("Material definition is required")

        if not self.geometry:
            errors.append("Plate geometry is required")
        elif self.geometry:
            if self.geometry.get("thickness", 0) <= 0:
                errors.append("Plate thickness must be positive")
            if self.geometry.get("n_chord", 0) < 2 or self.geometry.get("n_span", 0) < 2:
                errors.append("Mesh density too low (minimum 2 elements per direction)")

        if not self.boundary_conditions:
            errors.append("Boundary conditions are required")

        if not self.aerodynamic_config:
            errors.append("Aerodynamic configuration is required")
        elif self.aerodynamic_config:
            flow_conditions = self.aerodynamic_config.get("flow_conditions", {})
            if not flow_conditions.get("mach_numbers"):
                errors.append("At least one Mach number is required")
            if not flow_conditions.get("velocities"):
                errors.append("Analysis velocities are required")

        if not self.analysis_params:
            errors.append("Analysis parameters are required")

        return errors

class ProjectManager:
    """Manages panel flutter analysis projects."""

    def __init__(self, projects_dir: str = "projects"):
        self.projects_dir = Path(projects_dir)
        self.projects_dir.mkdir(exist_ok=True)
        self.current_project: Optional[Project] = None
        self.recent_projects: List[Project] = []
        self._load_recent_projects()

    def create_project(self, name: str, description: str = "") -> Project:
        """Create a new project."""
        now = datetime.now()
        project_id = f"{now.strftime('%Y%m%d_%H%M%S')}_{name.replace(' ', '_').lower()}"

        project = Project(
            id=project_id,
            name=name,
            created_at=now,
            modified_at=now,
            description=description if description else None
        )

        # Create project directory
        project_dir = self.projects_dir / project_id
        project_dir.mkdir(exist_ok=True)
        project.project_directory = str(project_dir)

        self.current_project = project
        self._add_to_recent(project)

        return project

    def validate_project(self, project: Project) -> tuple[bool, str]:
        """
        Validate project parameters.

        Returns:
            (is_valid, message)
        """
        if not VALIDATOR_AVAILABLE:
            return True, "Validation skipped (validator not available)"

        try:
            validator = ProjectValidator()
            project_dict = project.to_dict()
            is_valid, issues = validator.validate_project(project_dict)

            if not issues:
                return True, "[OK] Validation passed - no issues found"

            # Build message
            error_count = validator.get_error_count()
            warning_count = validator.get_warning_count()

            message = f"Validation: {error_count} error(s), {warning_count} warning(s)\n\n"

            for issue in issues:
                message += f"[{issue.level}] {issue.category}: {issue.message}\n"
                if issue.fix_suggestion:
                    message += f"  Fix: {issue.fix_suggestion}\n"
                message += "\n"

            return is_valid, message.strip()

        except Exception as e:
            print(f"Validation error: {e}")
            return True, f"Validation failed: {e}"

    def save_project(self, project: Optional[Project] = None) -> bool:
        """Save project to file."""
        if project is None:
            project = self.current_project

        if not project:
            return False

        try:
            # Validate before saving
            is_valid, validation_msg = self.validate_project(project)
            if not is_valid:
                print(f"Project validation warnings:\n{validation_msg}")
                # Save anyway but print warnings

            project.modified_at = datetime.now()
            project_file = self.projects_dir / f"{project.id}.json"

            with open(project_file, 'w') as f:
                json.dump(project.to_dict(), f, indent=2, default=str)

            self._add_to_recent(project)
            return True

        except Exception as e:
            print(f"Error saving project: {e}")
            return False

    def save_current_project(self) -> bool:
        """Save the current project to file (convenience method)."""
        return self.save_project(self.current_project)

    def load_project(self, project_file: str) -> Optional[Project]:
        """Load project from file."""
        try:
            project_path = Path(project_file)
            if not project_path.exists():
                return None

            with open(project_path, 'r') as f:
                data = json.load(f)

            project = Project.from_dict(data)

            # Validate loaded project
            is_valid, validation_msg = self.validate_project(project)
            if not is_valid:
                print(f"\n{'='*80}")
                print(f"WARNING: Project validation failed")
                print(f"{'='*80}")
                print(validation_msg)
                print(f"{'='*80}\n")
                # Still load but warn user
            elif VALIDATOR_AVAILABLE:
                # Check for warnings even if valid
                if "WARNING" in validation_msg or "warning" in validation_msg:
                    print(f"Project loaded with warnings:\n{validation_msg}")

            self.current_project = project
            self._add_to_recent(project)

            return project

        except Exception as e:
            print(f"Error loading project: {e}")
            return None

    def get_recent_projects(self) -> List[Project]:
        """Get list of recent projects."""
        return self.recent_projects[:10]  # Return only the 10 most recent

    def _add_to_recent(self, project: Project):
        """Add project to recent projects list."""
        # Remove if already in list
        self.recent_projects = [p for p in self.recent_projects if p.id != project.id]
        # Add to beginning
        self.recent_projects.insert(0, project)
        # Keep only last 10
        self.recent_projects = self.recent_projects[:10]
        # Save recent projects
        self._save_recent_projects()

    def _load_recent_projects(self):
        """Load recent projects from file."""
        recent_file = self.projects_dir / "recent_projects.json"
        if not recent_file.exists():
            return

        try:
            with open(recent_file, 'r') as f:
                data = json.load(f)

            self.recent_projects = []
            for project_data in data:
                try:
                    project = Project.from_dict(project_data)
                    # Check if project file still exists
                    project_file = self.projects_dir / f"{project.id}.json"
                    if project_file.exists():
                        self.recent_projects.append(project)
                except Exception:
                    continue  # Skip corrupted entries

        except Exception:
            self.recent_projects = []

    def _save_recent_projects(self):
        """Save recent projects to file."""
        recent_file = self.projects_dir / "recent_projects.json"
        try:
            data = [project.to_dict() for project in self.recent_projects]
            with open(recent_file, 'w') as f:
                json.dump(data, f, indent=2, default=str)
        except Exception:
            pass  # Fail silently

    def delete_project(self, project: Project) -> bool:
        """Delete a project and its files."""
        try:
            # Remove project file
            project_file = self.projects_dir / f"{project.id}.json"
            if project_file.exists():
                project_file.unlink()

            # Remove from recent projects
            self.recent_projects = [p for p in self.recent_projects if p.id != project.id]
            self._save_recent_projects()

            # Clear current project if it's the one being deleted
            if self.current_project and self.current_project.id == project.id:
                self.current_project = None

            # Remove project directory if it exists
            if project.project_directory:
                project_dir = Path(project.project_directory)
                if project_dir.exists() and project_dir.is_dir():
                    import shutil
                    shutil.rmtree(project_dir)

            return True

        except Exception as e:
            print(f"Error deleting project: {e}")
            return False